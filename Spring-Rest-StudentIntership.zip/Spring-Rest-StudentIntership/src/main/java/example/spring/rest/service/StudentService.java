package example.spring.rest.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import example.spring.rest.entity.Student;
import example.spring.rest.repository.StudentRepository;

@Service
public class StudentService {
	@Autowired
private StudentRepository stdRepo;
	
	public List<Student> getAllStudent(){
		List<Student> allStudents=stdRepo.findAll();
		return allStudents; 
	}
	
	public Student getOneStudent(Integer studentId) {
		Optional<Student> stdOpt=stdRepo.findById(studentId);
		Student foundStudent=stdOpt.get();
		return foundStudent;
		
	}
	public Student createStudent(Student student) {
		Student createdStudent=stdRepo.save(student);
		return createdStudent;
	}
	
	

	public void updateOneStudent(Student student) {
		Integer studentId=student.getStudentId();
		String firstName=student.getFirstName();
		String lastName=student.getLastName();
		Long moNumber=student.getMoNumber()	;
		String address=student.getAddress()	;
		
		stdRepo.updateOneStudent(studentId,firstName,lastName,moNumber,address);
		
		
	}

	public void deleteOneStudent(Integer studentId) {
		stdRepo.deleteById(studentId);
		
	}
	
	}
	