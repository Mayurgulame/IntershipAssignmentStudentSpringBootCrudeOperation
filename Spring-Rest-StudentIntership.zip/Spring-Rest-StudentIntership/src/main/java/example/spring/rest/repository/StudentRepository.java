package example.spring.rest.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import example.spring.rest.entity.Student;
import jakarta.transaction.Transactional;

public interface StudentRepository extends JpaRepository<Student, Integer> {
	@Transactional
	@Modifying
	@Query("update Student s set s.firstName = :firstName, s.lastName = :lastName, s.moNumber = :moNumber, s.address = :address where s.studentId = :studentId")
	void updateOneStudent(Integer studentId, String firstName, String lastName, Long moNumber, String address);

}
