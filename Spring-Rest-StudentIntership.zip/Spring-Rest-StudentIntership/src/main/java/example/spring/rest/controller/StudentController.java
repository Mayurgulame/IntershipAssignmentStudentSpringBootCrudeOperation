package example.spring.rest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import example.spring.rest.entity.Student;
import example.spring.rest.service.StudentService;

@RestController
public class StudentController {
@Autowired
private StudentService stdService;

@GetMapping("/student-api")
	public List <Student> getAllStudents(){
		List<Student> allStudent=stdService.getAllStudent();
		return allStudent;
	}
@GetMapping("/student-api/{stdId}")
public Student getOneStudent(@PathVariable ("stdId")Integer studentId) {
	Student foundStudent=stdService.getOneStudent(studentId);
	return foundStudent;
	
}
@PostMapping("/student-api")
public Student createNewStudent(@RequestBody Student student) {
	System.out.println("student is getting created"+ student);
	Student createdStudent=stdService.createStudent(student);
	return createdStudent;
}
@PutMapping("/student-api/{studentId}")
public void updateOneStudent(@RequestBody Student student) {
	System.out.println("student is getting updated");
	stdService.updateOneStudent(student);
}
@DeleteMapping("/student-api/{studentId}")
public void deleteOneStudent(@PathVariable Integer studentId) {
	stdService.deleteOneStudent(studentId);
}
}


