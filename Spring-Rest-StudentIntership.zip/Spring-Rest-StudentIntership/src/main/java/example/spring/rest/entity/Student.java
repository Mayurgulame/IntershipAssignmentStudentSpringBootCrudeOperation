package example.spring.rest.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="Student_Intership_Table_Master")
public class Student {
	@Id
	@Column
public Integer studentId;
	@Column
public String firstName;
	@Column
public String lastName;
	@Column
public long moNumber;
	@Column
public String address;
public Student() {
	super();
	// TODO Auto-generated constructor stub
}
public Student(Integer studentId, String firstName, String lastName, long moNumber, String address) {
	super();
	this.studentId = studentId;
	this.firstName = firstName;
	this.lastName = lastName;
	this.moNumber = moNumber;
	this.address = address;
}
public Integer getStudentId() {
	return studentId;
}
public void setStudentId(Integer studentId) {
	this.studentId = studentId;
}
public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) {
	this.lastName = lastName;
}
public long getMoNumber() {
	return moNumber;
}
public void setMoNumber(long moNumber) {
	this.moNumber = moNumber;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
@Override
public String toString() {
	return "Student [studentId=" + studentId + ", firstName=" + firstName + ", lastName=" + lastName + ", moNumber="
			+ moNumber + ", address=" + address + "]";
}

}
