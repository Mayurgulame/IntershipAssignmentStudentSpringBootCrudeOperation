package example.spring.rest.SpringRestStudentIntership;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringRestStudentIntershipApplicationTests {

	@Test
	void contextLoads() {
	}

}
